%% Call the initialization file for closed loop swarming mpc

cl_init


%% Call the run file to simulate swarming

cl_run


%% Call the analysis file to evaluate the swarm performance

cl_analyze
