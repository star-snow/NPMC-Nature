tic;

for  i = 1:10
    for j = 1:30
    end
    waitfor(rate);
end

toc;